import json
import re
import sys

import requests
import scrapy
from colorama import init,Fore, Back, Style
init(autoreset=True,convert=True)

from p_and_g_kcp_lazada.pipelines import *
from p_and_g_kcp_lazada.config import *

class KcpLazadaSpider(scrapy.Spider):
    name = 'kcp_lazada'

    def __init__(self,start='',end='',region='',feed=''):
        self.start = start
        self.end = end
        self.region = region
        self.feed = feed

    def start_requests(self):
        self.dir , self.select_time_list , self.feed = makeHTML(region=self.region,feed=self.feed)

        self.cursor , self.con , self.new_table_name, append_or_not = PAndGKcpLazadaPipeline.create_table(self, self.region)
        print(self.new_table_name)
        if append_or_not == 'yes':
            update = f'update category set status = "Done" where market = "{self.region}"'
            self.cursor.execute(update)
            self.con.commit()
        else:
            sqltablecheck = f'SELECT id,market,category,Sellername FROM {db_input_sku} where Status="Pending" AND ID BETWEEN {self.start} AND {self.end}'
            self.cursor.execute(sqltablecheck)
            rep = self.cursor.fetchall()
            for i in rep:
                id = i[0]
                market = i[1]
                category = i[2]
                p = category.split('/')
                url = p[3]
                domain = p[2]
                Sellername = p[3]

                if '?q=' in category:
                    cat = str(category).split("?q=")[0]
                elif '?spm=' in category:
                    cat = str(category).split("?spm=")[0]
                elif 'ajax' in category:
                    cat = category
                else:
                    return None

                delete_query = f"delete from {self.new_table_name} where id1='{id}'"
                self.cursor.execute(delete_query)
                self.con.commit()



                if 'ajax' in category:
                    pl_url = cat
                else:
                    if market == 'ID':
                        pl_url = f'{cat}?ajax=true&from=wangpu&isFirstRequest=true&lang={market}&langFlag={market}&page=1&pageTypeId=2&q=All-Products&spm=a2o4j.8553159.0.0.7ea813abFBZbco'
                    elif market == 'VN':
                        pl_url = f'{cat}?ajax=true&from=wangpu&isFirstRequest=true&lang=vi&langFlag=vi&page=1&pageTypeId=2&q=All-Products'
                    elif market == 'SG':
                        pl_url = f'{cat}?ajax=true&from=wangpu&isFirstRequest=true&langFlag=en&page=1&pageTypeId=2&q=All-Products'
                    elif id == 17:
                        pl_url = f'{cat}?ajax=true&from=wangpu&isFirstRequest=true&langFlag=th&page=1&pageTypeId=2&q=All-Products'
                    else:
                        pl_url = f'{cat}?ajax=true&from=wangpu&isFirstRequest=true&lang=en&langFlag=en&page=1&pageTypeId=2&q=All-Products'
                filename = f'Brand_{market}_{id}_Page_1.json'
                path = self.dir + '\\' + filename
                path = path.replace('\\\\', '\\')

                meta = {'pl_url': pl_url,
                         'category':category,
                         'market':market,
                         'id':id,
                         'total_page':1,
                         'total_count':0,
                         'page_number':0,
                         'path':path,
                         'Sellername':Sellername
                        }

                if os.path.exists(path):
                    yield scrapy.Request(url=f'file:{path}',callback=self.parse,meta=meta)
                else:
                    main_req = pl_link(url=pl_url,region=market)
                    if not 'categories' in main_req.text:
                        for i in range(2):
                            if not 'categories' in main_req.text:
                                main_req = pl_link(url=pl_url, region=self.region)
                                print(Fore.YELLOW + "========please change cookie=============")
                    pes = main_req.text
                    with open(path, 'w', encoding='utf8') as f:
                        f.write(pes)
                    if os.path.getsize(path) < 6000:
                        os.remove(path)
                        continue
                    yield scrapy.Request(url=f'file:{path}', callback=self.parse, meta=meta)
                # for i in range(2):
                #     if ('captcha' in pes) or ('Request failed' in pes):
                #         main_req = pl_link(url=pl_url, region=market)
                #         pes = main_req.text
                #         print(Fore.YELLOW + "========please change cookie=============")
                #     elif not ('itemUrl' in pes) and ('totalResults' in pes):
                #         main_req = pl_link(url=pl_url, region=market)
                #         pes = main_req.text
                #         print(Fore.YELLOW +"========please change cookie=============")
                #     # elif main_req.status_code==404 and 'itemUrl' not in pes:
                #     #     with open(path, 'w',encoding='utf8') as f:
                #     #         f.write(pes)
                #     else:
                #         while ('captcha' in pes) or ('Request failed' in pes):
                #             main_req = pl_link(url=pl_url, region=market)
                #             pes = main_req.text
                #             print(Fore.YELLOW +"========please change cookie=============")
                #         while not ('itemUrl' in pes) and ('totalResults' in pes):
                #             main_req = pl_link(url=pl_url, region=market)
                #             pes = main_req.text
                #             print(Fore.YELLOW +"========please change cookie=============")
                #         with open(path, 'w',encoding='utf8') as f:
                #             f.write(pes)
                #         # if os.path.getsize(path) < 6000:
                #         #     os.remove(path)
                #         #     continue
                #
                #         yield scrapy.Request(url=f'file:{path}', callback=self.parse,meta=meta)

    def parse(self, response, **kwargs):
            jdata = json.loads(response.text)
            pl_url = response.meta.get('pl_url')
            id = response.meta.get('id')
            market = response.meta.get('market')
            page_number = response.meta.get('page_number')
            total_page = response.meta.get('total_page')
            total_count = response.meta.get('total_count')
            category = response.meta.get('category')
            path = response.meta.get('path')
            fetch_Sellername = response.meta.get('Sellername')
            res = response.text

            try:
                if total_page == 1:
                    totalresults = jdata['mainInfo']['totalResults']
                    page_number = int((int(totalresults) / 40) + 1)

                try:
                    if total_page <= page_number:
                        print(Fore.CYAN + f'------------------------------------------{total_page}---------------------------------------')
                        for i in jdata['mods']['listItems']:
                            dllobj.intialize_variable()
                            print(Fore.GREEN + f'------------------------------------{total_count}--------------------------------------')

                            all_urls = i['itemUrl']
                            url = f'http:{all_urls}'

                            dllobj.Page_Url = category

                            #TODO SKUID
                            try:
                                if 'cheapest_sku' in res:
                                    cheapest_sku = i['cheapest_sku']
                                else:
                                    cheapest_sku = i['']
                                dllobj.SKU_ID = cheapest_sku
                            except Exception as e:
                                print("Error in Sku id .....",e)
                                return None

                            #TODO Price
                            try:
                                if 'priceShow' in res:
                                    liprice = i['priceShow']
                                    print("Price================", liprice)
                                    # if self.region=='MY':
                                    if liprice:
                                        if self.region == 'ID' or self.region == 'VN':
                                            liprice = int(''.join(filter(str.isdigit, liprice)))
                                        elif '.00' in str(liprice):
                                            liprice = str(liprice).split(".")[0]
                                            liprice = int(''.join(filter(str.isdigit, liprice)))
                                        else:
                                            liprice = liprice
                                    else:
                                        liprice = liprice
                                    liprice = str(liprice)
                                else:
                                    liprice = ''
                                print("DLLOBJ>>>Price================", liprice)
                                liprice = re.sub("[^.0-9]", "", liprice)
                                dllobj.Price = str(liprice).encode('ascii', 'ignore').decode("utf-8","surrogateescape").replace(
                                    ",", "")
                                print("DLLOBJ>>>Price=====AFTER   ===========", liprice)
                            except Exception as e:
                                print("Error in Price.......", e)
                                return None

                            #TODO Product Name
                            try:
                                name = i['name']
                                if name!=None:
                                    dllobj.SKU_Name = name
                                else:
                                    print("Name Not available Check......")
                                    return None
                            except Exception as e:
                                print("Error in Product Name Please Check .......",e)
                                return None

                            #TODO Seller Name
                            try:
                                sellerName = i['sellerName']
                                if sellerName=='' or sellerName==None:
                                    sellerName = fetch_Sellername
                                else:
                                    sellerName = sellerName
                                dllobj.Seller_Name = sellerName
                            except Exception as e:
                                print("Error in Seller Name check fast.......",e)

                            # TODO InStock
                            try:
                                availability = i['inStock']
                                if availability == True:
                                    availability = 'TRUE'
                                    stock = '1'
                                else:
                                    availability = 'FALSE'
                                    stock = '0'
                                dllobj.InStock = str(availability)
                                dllobj.Stock = str(stock)
                            except Exception as e:
                                print("Error in Availability .....", e)

                            #TODO Brand
                            try:
                                brand = i['brandName']
                                if brand!=None:
                                    brand = brand
                                else:
                                    brand=''
                                dllobj.Brand = str(brand)
                            except Exception as e:
                                print("Error in Brand ...... ",e)


                            dllobj.SKU_Url = url
                            dllobj.Date = datetime.today().strftime('%m/%d/%Y')

                            # todo htmlpath
                            dd = self.dir + f'Brand_{market}_{id}_Page_{total_page}.json'
                            dllobj.htmlpath = dd

                            # todo extra
                            dllobj.Retailer = 'Lazada'
                            dllobj.Country = str(self.region)
                            dllobj.id1 = str(id)
                            dllobj.status = 'Done'

                            print('page url ---', url)

                            try:
                                error_msg = dllobj.QA_check()
                                if error_msg == '':
                                    print(dllobj.Insert_Query(self.select_time_list))
                                    insert_q = dllobj.Insert_Query(self.select_time_list)
                                    region = self.region.lower()
                                    select_time_list=self.select_time_list
                                    new_table_name = f"pg_pricestock_productdata_{old_td}_{region}_{select_time_list}"
                                    if "pg_PriceStock_productdata" in insert_q:
                                        insert_q = insert_q.replace(f'pg_PriceStock_productdata_{old_td}_{self.select_time_list}', f'{new_table_name}').replace('status','status_1')
                                    print(insert_q)
                                    self.cursor.execute(insert_q)
                                    self.con.commit()
                                else:
                                    print("Error msg ::: ",error_msg)
                            except Exception as e:
                                print(Fore.RED + 'Error in inserting data ==', e)
                            total_count += 1

                        try:
                            total_page += 1
                            if total_page <= page_number:
                                print(
                                    Fore.YELLOW + "============================================Next Page===================================")
                                filename = f'Brand_{market}_{id}_Page_{total_page}.json'
                                next_path = self.dir + filename
                                next_path = str(next_path).replace("\\\\","//")
                                # todo htmlpath
                                dllobj.htmlpath = next_path
                                meta = {'pl_url': pl_url,
                                        'category': category,
                                        'market': market,
                                        'id': id,
                                        'total_page': total_page,
                                        'total_count': total_count,
                                        'page_number': page_number,
                                        'path': path,
                                        'Sellername':fetch_Sellername
                                        }
                                next_url = pl_url.replace('page=1', f'page={total_page}')
                                if os.path.exists(next_path):
                                    yield scrapy.Request(url=f'file:{next_path}', callback=self.parse, meta=meta)
                                else:
                                    next_req = pl_link(url=next_url, region=market)
                                    nes = next_req.text
                                    for i in range(2):
                                        if ('captcha' in nes) or ('Request failed' in nes):
                                            next_req = pl_link(url=pl_url, region=market)
                                            nes = next_req.text
                                            print(Fore.YELLOW + "========please change cookie=============")
                                        elif not ('itemUrl' in nes) and ('totalResults' in nes):
                                            next_req = pl_link(url=pl_url, region=market)
                                            nes = next_req.text
                                            print(Fore.YELLOW + "========please change cookie=============")
                                        elif next_req.status_code==404:
                                            with open(next_path, 'w', encoding='utf8') as f:
                                                f.write(nes)
                                        else:
                                            with open(next_path, 'w', encoding='utf8') as f:
                                                f.write(nes)
                                            if os.path.getsize(next_path) < 6000:
                                                os.remove(next_path)
                                                continue

                                            yield scrapy.Request(url=f'file:{next_path}', callback=self.parse, meta=meta)
                            else:
                                updatequery = f'update category set status = "Done" , totalcount="{total_count}", count="{total_count}" where id = {id}'
                                self.cursor.execute(updatequery)
                                self.con.commit()
                                print(Fore.GREEN + "Updated ALL")
                        except Exception as e:
                            print(Fore.RED + 'Error in 2nd try block --- ', e)
                    else:
                        updatequery = f'update category set status = "Done" , totalcount="{total_count}", count="{total_count}" where id = {id}'
                        self.cursor.execute(updatequery)
                        self.con.commit()
                        print(Fore.GREEN + "Updated ALL")
                except Exception as e:
                    exception_type, exception_object, exception_traceback = sys.exc_info()
                    line_number = exception_traceback.tb_lineno
                    print(Fore.RED + "Error in main try block --- : ", e, line_number)
            except Exception as e:
                print(Fore.RED + 'Error in last block --- ', e)

    def close(self, spider, reason):
        try:
            prod_sql = f"SELECT * FROM {db_input_sku} WHERE status='Pending' and Market='{self.region}'"
            print(prod_sql)
            self.cursor = spider.cursor
            self.cursor.execute(prod_sql)

            rows = self.cursor.fetchall()
            if rows == ():
                try:
                    selectquery = f"select `sku id`,`sku name`,id from pg_web_availability_inputs_{self.region}"
                    self.cursor.execute(selectquery)
                    table = self.cursor.fetchall()
                    for row in table:
                        sku_id = row[0]
                        sku_name = row[1]
                        id = row[2]
                        selectquery2 = f"select sku_id from {self.new_table_name}"
                        self.cursor.execute(selectquery2)
                        table2 = self.cursor.fetchall()
                        if (sku_id,) not in table2:
                            try:
                                print(Fore.CYAN + f'----------------------------------------inputs id no. = {id}---------------------------------------')
                                insertquery = f'''INSERT INTO {self.new_table_name} (status_1,sku_id,sku_name) VALUES ('Pending','{sku_id}','{sku_name}')'''.replace(
                                    "'s", 's').replace("'m", "m")
                                insertquery = c_replace(insertquery)
                                self.cursor.execute(insertquery)
                                self.con.commit()
                            except Exception as e:
                                print(sku_id)
                                print(Fore.RED + 'Error in inserting data ==', e)
                        else:
                            continue
                    print(Fore.GREEN + '!!!!!!!!!!!!!!!!Mapping Sucessfully Done!!!!!!!!!!!!!!!!!!!!!!!!!')
                except Exception as e:
                    print(Fore.RED + 'Error while fetching url from inputs table --- ', e)
                print('spider is close,...................')
                print('going on QA and make csv..............')
                from p_and_g_kcp_lazada.dll_export_csv import Export_Csv
                c = Export_Csv()
                c.export_csv(self.region, self.feed)

            else:
                print('some entries are pending')
        except Exception as e:
            print(e)

if __name__ == '__main__':
    from scrapy.cmdline import execute
    # execute('scrapy crawl kcp_lazada -a region=ID -a feed=1263 -a start=1 -a end=10000000'.split())
    # execute('scrapy crawl kcp_lazada -a region=MY -a feed=1264 -a start=1 -a end=10000000'.split())
    execute('scrapy crawl kcp_lazada -a region=PH -a feed=1265 -a start=10 -a end=10'.split())
    # execute('scrapy crawl kcp_lazada -a region=SG -a feed=1266 -a start=12 -a end=12'.split())
    # execute('scrapy crawl kcp_lazada -a region=TH -a feed=1267 -a start=24 -a end=24'.split())
    # execute('scrapy crawl kcp_lazada -a region=VN -a feed=1268 -a start=1 -a end=10000000'.split())

