# import json
# import re
# import sys
#
# import requests
# import scrapy
# from colorama import init,Fore, Back, Style
# init(autoreset=True,convert=True)
#
# from p_and_g_kcp_lazada.pipelines import *
# from p_and_g_kcp_lazada.config import *
#
# class KcpLazadaSpider(scrapy.Spider):
#     name = 'kcp_lazada'
#
#     def __init__(self,start='',end='',region=''):
#         self.start = start
#         self.end = end
#         self.region = region
#
#     def start_requests(self):
#         self.dir , self.select_time_list = makeHTML(region=self.region)
#
#         self.cursor , self.con , self.new_table_name = PAndGKcpLazadaPipeline.create_table(self, self.region)
#         print(self.new_table_name)
#         deletequery = f'delete from {self.new_table_name} where id between 1 and 10000'
#         print(deletequery)
#         self.cursor.execute(deletequery)
#         self.con.commit()
#
#         sqltablecheck = f'SELECT id,market,category FROM {db_input_sku} where Status="Pending" AND ID BETWEEN {self.start} AND {self.end}'
#         self.cursor.execute(sqltablecheck)
#         rep = self.cursor.fetchall()
#         for i in rep:
#             id = i[0]
#             market = i[1]
#             category = i[2]
#             p = category.split('/')
#             url = p[3]
#             domain = p[2]
#
#             if 'ajax' in category:
#                 pl_url = category
#             else:
#                 if market == 'ID':
#                     pl_url = f'https://{domain}/{url}/?ajax=true&from=wangpu&isFirstRequest=true&lang={market}&langFlag={market}&page=1&pageTypeId=2&q=All-Products&spm=a2o4j.8553159.0.0.7ea813abFBZbco'
#                 elif market == 'VN':
#                     pl_url = f'https://{domain}/{url}/?ajax=true&from=wangpu&isFirstRequest=true&lang=vi&langFlag=vi&page=1&pageTypeId=2&q=All-Products'
#                 elif market == 'SG':
#                     pl_url = f'https://{domain}/{url}/?ajax=true&from=wangpu&isFirstRequest=true&langFlag=en&page=1&pageTypeId=2&q=All-Products'
#                 elif id == 17:
#                     pl_url = f'https://{domain}/{url}/?ajax=true&from=wangpu&isFirstRequest=true&langFlag=th&page=1&pageTypeId=2&q=All-Products'
#                 else:
#                     pl_url = f'https://{domain}/{url}/?ajax=true&from=wangpu&isFirstRequest=true&lang=en&langFlag=en&page=1&pageTypeId=2&q=All-Products'
#             total_page = 1
#             total_count = 0
#             filename = f'Brand_{market}_{id}_Page_{total_page}.json'
#             path = self.dir + '\\' + filename
#             path = path.replace('\\\\', '\\')
#
#             meta = {'pl_url': pl_url,
#                      'category':category,
#                      'market':market,
#                      'id':id,
#                      'total_page':total_page,
#                      'total_count':total_count,
#                      'page_number':0,
#                     'path':path}
#
#             if os.path.exists(path):
#                 yield scrapy.Request(url=f'file:{path}',callback=self.parse,meta=meta)
#             else:
#                 main_req = pl_link(url=pl_url,region=market)
#                 pes = main_req.text
#                 for i in range(2):
#                     if ('captcha' in pes) or ('Request failed' in pes):
#                         main_req = pl_link(url=pl_url, region=market)
#                         pes = main_req.text
#                         print(Fore.YELLOW + "========please change cookie=============")
#                     elif not ('itemUrl' in pes) and ('totalResults' in pes):
#                         main_req = pl_link(url=pl_url, region=market)
#                         pes = main_req.text
#                         print(Fore.YELLOW +"========please change cookie=============")
#                     else:
#                         with open(path, 'w',encoding='utf8') as f:
#                             f.write(pes)
#                         if os.path.getsize(path) < 6000:
#                             os.remove(path)
#                             continue
#
#                         yield scrapy.Request(url=f'file:{path}', callback=self.parse,meta=meta)
#
#                     # while ('captcha' in pes) or ('Request failed' in pes):
#                     #     main_req = pl_link(url=pl_url, region=market)
#                     #     pes = main_req.text
#                     #     print(Fore.YELLOW +"========please change cookie=============")
#                     # while not ('itemUrl' in pes) and ('totalResults' in pes):
#                     #     main_req = pl_link(url=pl_url, region=market)
#                     #     pes = main_req.text
#                     #     print(Fore.YELLOW +"========please change cookie=============")
#                     # with open(path, 'w',encoding='utf8') as f:
#                     #     f.write(pes)
#                     # if os.path.getsize(path) < 6000:
#                     #     os.remove(path)
#                     #     continue
#                     #
#                     # yield scrapy.Request(url=f'file:{path}', callback=self.parse,meta=meta)
#
#     def parse(self, response, **kwargs):
#         jdata = json.loads(response.text)
#         pl_url = response.meta.get('pl_url')
#         id = response.meta.get('id')
#         market = response.meta.get('market')
#         page_number = response.meta.get('page_number')
#         total_page = response.meta.get('total_page')
#         total_count = response.meta.get('total_count')
#         category = response.meta.get('category')
#         path = response.meta.get('path')
#
#         try:
#             if total_page == 1:
#                 totalresults = jdata['mainInfo']['totalResults']
#                 page_number = int((int(totalresults) / 40) + 1)
#
#             try:
#                 if total_page <= page_number:
#                     print(Fore.CYAN + f'------------------------------------------{total_page}---------------------------------------')
#                     for i in jdata['mods']['listItems']:
#                         print(Fore.GREEN +f'------------------------------------{total_count}--------------------------------------')
#
#                         all_urls = i['itemUrl']
#                         url = f'http:{all_urls}'
#
#
#                         # todo page_url,cheaspest(sku_id),listprice,saleprice
#
#                         dllobj.Page_Url = category
#                         cheapest_sku = i['cheapest_sku']
#                         # listprice = i['originalPriceShow']
#                         liprice = i['priceShow']
#                         liprice = re.findall('[0-9]+', liprice)
#                         liprice = ".".join(liprice)
#                         if liprice > '0':
#                             dllobj.InStock = 'True'
#                         else:
#                             dllobj.InStock = 'False'
#                         name = i['name']
#                         sellerName = i['sellerName']
#
#                         dllobj.Seller_Name = sellerName
#                         dllobj.SKU_Name = name
#                         dllobj.SKU_Url = url
#                         dllobj.Price = str(liprice)
#                         dllobj.SKU_ID = cheapest_sku
#                         dllobj.Date = datetime.today().strftime('%m/%d/%Y')
#
#                         #todo htmlpath
#                         dd = self.dir + f'Brand_{market}_{id}_Page_{total_page}.json'
#                         dllobj.htmlpath = dd
#
#                         #todo extra
#                         dllobj.Retailer = 'Lazada'
#                         dllobj.Country = str(self.region)
#                         dllobj.id1 = str(id)
#                         dllobj.status = 'Done'
#
#
#                         print('page url ---', url)
#
#
#                         try:
#                             error_msg = dllobj.QA_check()
#                             if error_msg == '':
#                                 print(dllobj.Insert_Query(self.select_time_list))
#                                 insert_q = dllobj.Insert_Query(self.select_time_list)
#                                 if "pg_PriceStock_productdata" in insert_q:
#                                     insert_q = insert_q.replace(f'pg_PriceStock_productdata_{old_td}_{self.select_time_list}', f'{self.new_table_name}').replace('status','status_1')
#                                 print(insert_q)
#                                 self.cursor.execute(insert_q)
#                                 self.con.commit()
#                         except Exception as e:
#                             print(Fore.RED + 'Error in inserting data ==', e)
#                         total_count += 1
#
#                     try:
#                         total_page += 1
#                         if total_page <= page_number:
#                             print(Fore.YELLOW + "============================================Next Page===================================")
#                             filename = f'Brand_{market}_{id}_Page_{total_page}.json'
#                             next_path = self.dir + filename
#                             # todo htmlpath
#                             dllobj.htmlpath = next_path
#                             meta = {'pl_url': pl_url,
#                                     'category': category,
#                                     'market': market,
#                                     'id': id,
#                                     'total_page': total_page,
#                                     'total_count': total_count,
#                                     'page_number': page_number,
#                                     'path':path}
#                             next_url = pl_url.replace('page=1',f'page={total_page}')
#                             if os.path.exists(next_path):
#                                 yield scrapy.Request(url=f'file:{next_path}', callback=self.parse,meta=meta)
#                             else:
#                                 next_req = pl_link(url=next_url,region=market)
#                                 nes = next_req.text
#                                 for i in range(2):
#                                     if ('captcha' in nes) or ('Request failed' in nes):
#                                         next_req = pl_link(url=pl_url, region=market)
#                                         nes = next_req.text
#                                         print(Fore.YELLOW + "========please change cookie=============")
#                                     elif not ('itemUrl' in nes) and ('totalResults' in nes):
#                                         next_req = pl_link(url=pl_url, region=market)
#                                         nes = next_req.text
#                                         print(Fore.YELLOW + "========please change cookie=============")
#                                     else:
#                                         with open(path, 'w', encoding='utf8') as f:
#                                             f.write(nes)
#                                         if os.path.getsize(path) < 6000:
#                                             os.remove(path)
#                                             continue
#
#                                         yield scrapy.Request(url=f'file:{path}', callback=self.parse, meta=meta)
#
#                                 # while ('captcha' in nes) or ('Request failed' in nes):
#                                 #     next_req = pl_link(url=next_url, region=market)
#                                 #     nes = next_req.text
#                                 #     print(Fore.YELLOW +"========please change cookie=============")
#                                 # while not ('itemUrl' in nes) and ('totalResults' in nes):
#                                 #     next_req = pl_link(url=next_url, region=market)
#                                 #     nes = next_req.text
#                                 #     print(Fore.YELLOW +"========please change cookie=============")
#                                 # if '404 not found' in nes:
#                                 #     print(Fore.YELLOW +"========please change cookie=============")
#                                 #     pass
#                                 # with open(next_path, 'w', encoding='utf8') as f:
#                                 #     f.write(nes)
#                                 # if os.path.getsize(next_path) < 6000:
#                                 #     os.remove(next_path)
#                                 #     pass
#                                 # yield scrapy.Request(url=f'file:{next_path}', callback=self.parse,meta=meta)
#                         else:
#                             updatequery = f'update category set status = "Done" , totalcount="{total_count}", count="{total_count}" where id = {id}'
#                             self.cursor.execute(updatequery)
#                             self.con.commit()
#                             print(Fore.GREEN + "Updated ALL")
#                     except Exception as e:
#                         print(Fore.RED +'Error in 2nd try block --- ',e)
#                 else:
#                     updatequery = f'update category set status = "Done" , totalcount="{total_count}", count="{total_count}" where id = {id}'
#                     self.cursor.execute(updatequery)
#                     self.con.commit()
#                     print(Fore.GREEN + "Updated ALL")
#             except Exception as e:
#                 exception_type, exception_object, exception_traceback = sys.exc_info()
#                 line_number = exception_traceback.tb_lineno
#                 print(Fore.RED +"Error in main try block --- : ", e, line_number)
#         except Exception as e:
#             print(Fore.RED + 'Error in last block --- ', e)
#
# if __name__ == '__main__':
#     from scrapy.cmdline import execute
#     execute('scrapy crawl kcp_lazada -a region=SG -a start=11 -a end=13'.split())
