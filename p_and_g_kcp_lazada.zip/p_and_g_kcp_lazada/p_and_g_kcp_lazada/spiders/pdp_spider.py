import json
import re
import sys
import time
import requests
import scrapy
import selenium
from colorama import init,Fore , Back, Style
from logger import logger

init(autoreset=True,convert=True)
from scrapy import Selector

from p_and_g_kcp_lazada.pipelines import *
from p_and_g_kcp_lazada.config import *

class KcpLazadaSpider(scrapy.Spider):
    name = 'lazada_pdp'

    def __init__(self,start='',end='',region='',feed=''):
        self.start = start
        self.end = end
        self.region = region
        self.feed = feed

    def start_requests(self):
        try:
            # self.con = pymysql.connect(host=db_host, user=db_user, password=db_passwd, database=db_name,autocommit=True, use_unicode=True, charset="utf8")
            # self.cursor = self.con.cursor()

            self.dir, self.select_time_list, self.feed = makeHTML(region=self.region, feed=self.feed)
            # new_table_name = f"pg_pricestock_productdata_{old_td}_{self.region}_{self.select_time_list}"

            self.cursor, self.con, self.new_table_name = PAndGKcpLazadaPipeline.create_table_pdp(self, self.region)
            # try:
            #     self.cursor.execute(f"select * from {self.new_table_name}")
            #     results = self.cursor.fetchall()
            #     if results == ():
            #         PAndGKcpLazadaPipeline.create_table(self, self.region)
            #     else:
            #         pass
            # except Exception as e:
            #     PAndGKcpLazadaPipeline.create_table(self, self.region)
            #     print("Error in Table creation....", e)

            self.region = self.region.upper()
            if self.region == "ID":
                update = f'update {self.new_table_name} set status_1="Done" where status="Pending"'
                self.cursor.execute(update)
                self.con.commit()
            else:
                '---'

            sqltablecheck = f'SELECT id,sku_id,sku_url,price,id1,page_Url FROM {self.new_table_name} where Status="Pending" and ID BETWEEN {self.start} AND {self.end}'
            self.cursor.execute(sqltablecheck)
            rep = self.cursor.fetchall()
            for i in rep:
                id = i[0]
                cheapset = i[1]
                sku_url = i[2]
                plprice = i[3]
                id1 = i[4]
                page_url = i[5]

                split_cheapset = str(cheapset).split("-")[0]
                split_cheapset = split_cheapset + "-"
                # split_cheapset = cheapset

                if self.region == 'MY':
                    domain = 'https://www.lazada.com.my'
                elif self.region == 'VN':
                    domain = 'https://www.lazada.vn'
                elif self.region == 'ID':
                    domain = 'https://www.lazada.co.id'
                elif self.region == 'PH':
                    domain = 'https://www.lazada.com.ph'
                elif self.region == 'TH':
                    domain = 'https://www.lazada.co.th'
                elif self.region == 'SG':
                    domain = 'https://www.lazada.sg'
                else:
                    domain=''

                if sku_url == None:
                    try:
                        if self.region == 'MY':
                            url = f'{domain}/catalog/?_keyori=ss&ajax=true&from=input&isFirstRequest=true&page=1&q={split_cheapset}&spm=a2o4k'
                        elif self.region == 'VN':
                            url = f'{domain}/catalog/?_keyori=ss&ajax=true&from=input&isFirstRequest=true&page=1&q={split_cheapset}&spm=a2o4n'
                        elif self.region =='PH':
                            url = f'{domain}/catalog/?_keyori=ss&ajax=true&from=input&isFirstRequest=true&page=1&q={split_cheapset}&spm=a2o4l.home.search.go.239e7e66Q7Tdzk'
                            # url = f'https://www.lazada.com.ph/catalog/?_keyori=ss&ajax=true&from=input&isFirstRequest=true&page=1&q=1311440613_PH-4781572359&spm=a2o4l.home.search.go.239e7e66Q7Tdzk'
                        elif self.region == 'TH':
                            url = f'{domain}/catalog/?_keyori=ss&ajax=true&from=input&isFirstRequest=true&page=1&q={split_cheapset}&spm=a2o4m'
                        elif self.region == 'SG':
                            url = f'{domain}/catalog/?_keyori=ss&ajax=true&from=input&isFirstRequest=true&page=1&q={split_cheapset}&spm=a2o42'
                        else:
                            domain=''
                            url=''
                            return None
                        m_filename = f'{cheapset}_search.json'
                        m_path = self.dir + m_filename
                        if os.path.exists(m_path):
                            with open(m_path, 'r', encoding='utf8') as f:
                                pesa = f.read()
                        else:
                            main_req = pl_link(url=url,region=self.region)
                            pesa = main_req.text
                            while ('captcha' in pesa) or ('Request failed' in pesa):
                                main_req = pl_link(url=url, region=self.region)
                                pesa = main_req.text
                                print(Fore.YELLOW + "========please change cookie=============")
                            while not ('totalResults' in pesa):
                                main_req = pl_link(url=url, region=self.region)
                                pesa = main_req.text
                                print(Fore.YELLOW + "========please change cookie=============")
                            if (main_req.status_code==200 and 'mods' in pesa):
                                with open(m_path, 'w', encoding='utf8') as f:
                                    f.write(pesa)
                            elif not 'itemUrl' in pesa:
                                date = datetime.today().strftime('%m/%d/%Y')
                                time = datetime.today().strftime('%H:%M:%S')
                                update_status = f"update {self.new_table_name} set status='Not Found',`Brand`='',`Date`='{date}',`Time`='{time}',`Country`='{self.region}',`isVariant`='',`InStock`='FALSE',`Retailer`='Lazada' where id='{id}'"
                                self.cursor.execute(update_status)
                                self.con.commit()
                                print(Fore.LIGHTYELLOW_EX +">>>>>>>>>>>>>>>>> NOT FOUND STATUS UPDATED  <<<<<<<<<<<<<<<<<<<<")
                                pass
                        jdata = json.loads(pesa)
                        for i in jdata['mods']['listItems']:
                            urls = i['itemUrl']
                            if split_cheapset in pesa:
                                if 'http' in urls:
                                    sku_url = sku_url
                                else:
                                    sku_url = f'http:{urls}'
                            page_url = url
                            id1 = "0"
                    except Exception as e:
                        print(Fore.RED + 'Error in inserting data ==', e)
                else:
                    '--'

                if sku_url == None:
                    pass
                else:
                    #todo htmlpath
                    dllobj.htmlpath = self.dir
                    total_page = 1
                    total_count = 1
                    filename = f'{cheapset}.html'
                    path = self.dir + filename
                    # todo htmlpath_1
                    if self.region == 'ID':
                        dllobj.htmlpath = path
                    else:
                        dllobj.htmlpath_1 = path
                    meta_dict = {'id1':id1,
                                 'id':id,
                                 'page_url':page_url,
                                 'plprice':plprice,
                                 'cheapset':cheapset,
                                 'sku_url':sku_url,
                                 'total_page':total_page,
                                 'total_count':total_count,
                                 'path':path,
                                 'domain':domain}

                    if os.path.exists(path):
                        yield scrapy.Request(url=f'file:{path}', callback=self.parse, meta=meta_dict)
                    else:
                        main_req = pl_link(url=sku_url, region=self.region)
                        if main_req.status_code == 404:
                            updateq = f'update {self.new_table_name} set status="Not Found" where sku_id = "{cheapset}"'
                            self.cursor.execute(updateq)
                            self.con.commit()
                            pass
                            print(Fore.RED + '!!!!!!!!!!NOT FOUND!!!!!!!!!!!!!!!!}')
                        for i in range(2):
                            if not ('__moduleData__' in main_req.text):
                                main_req = pl_link(url=sku_url, region=self.region)
                                # res = main_req.text
                                print(Fore.YELLOW + "========please change cookie=============")
                            else:
                                res = main_req.text
                                with open(path, 'w', encoding='utf8') as f:
                                    f.write(res)
                                if os.path.getsize(path) < 6000:
                                    os.remove(path)
                                    continue

                                yield scrapy.Request(url=f'file:{path}', callback=self.parse, meta=meta_dict)
                        # res = main_req.text
                        # while not ('__moduleData__' in res):
                        #     main_req = pl_link(url=sku_url, region=self.region)
                        #     res = main_req.text
                        #     print(Fore.YELLOW +"========please change cookie=============")
                        # with open(path, 'w', encoding='utf8') as f:
                        #     f.write(res)
                        # if os.path.getsize(path) < 6000:
                        #     os.remove(path)
                        #     continue
                        #
                        # yield scrapy.Request(url=f'file:{path}', callback=self.parse,meta=meta_dict)
        except Exception as e:
            print(e)

    def parse(self, response, **kwargs):
        sku_url = response.meta.get('sku_url')
        # todo sku_url
        dllobj.SKU_Url = sku_url
        cheapset = response.meta.get('cheapset')
        plprice = response.meta.get('plprice')
        total_count = response.meta.get('total_count')
        id1 = response.meta.get('id1')
        id = response.meta.get('id')
        page_url = response.meta.get('page_url')
        domain = response.meta.get('domain')
        path = response.meta.get('path')



        r = response.text
        # TODO Fetch moduledata(json)
        moduledata = r.split(" var __moduleData__ = ")[1]
        moduledata = moduledata.split('var __googleBot__ = "";')[0]
        moduledata = moduledata.replace("};", "}")
        j_data = json.loads(moduledata)
        comman_data = j_data['data']['root']['fields']
        split = str(cheapset).split("-")[1]

        dllobj.intialize_variable()

        # todo varient_id
        dllobj.Variant_ID = split
        split_1 = comman_data['tracking']['pdt_simplesku']

        if comman_data['skuInfos'].get(split):
            skuinfos = comman_data['skuInfos'][split]
        else:
            skuinfos = comman_data['skuInfos'][str(split_1)]

        # todo sku_name
        pdt_name = comman_data['product']['title']
        dllobj.SKU_Name = pdt_name

        # todo sku_id,varient_id,sellername,price,stock

        if comman_data['specifications']:
            try:
                skuId = skuinfos['skuId']
                if comman_data['specifications'][skuId].get('features'):
                    sku = comman_data['specifications'][skuId]['features']['SKU']
                    dllobj.SKU_ID = sku
                elif comman_data['specifications'][skuId].get('popItems'):
                    sku = comman_data['productOption']['skuBase']['skus'][0]['innerSkuId']
                    dllobj.SKU_ID = sku
            except Exception as e:
                print(Fore.RED + 'Error in skuid == ',e)

            try:
                # todo sellername
                sellername = comman_data['tracking']['seller_name']
                dllobj.Seller_Name = sellername
            except Exception as e:
                print(Fore.RED + 'Error in Sellername == ',e)

            # todo price
            try:
                saleprice = skuinfos['price']['salePrice']['value']
                if self.region == 'ID' or self.region == 'VN':
                    if type(saleprice) != int:
                        saleprice = int(''.join(filter(str.isdigit, saleprice)))
                    else:
                        saleprice = saleprice
                elif '.00' in str(saleprice):
                    saleprice = str(saleprice).split(".")[0]
                else:
                    saleprice = saleprice
                saleprice = re.sub("[^.0-9]", "", str(saleprice))
                saleprice = str(saleprice).encode('ascii', 'ignore').decode("utf-8", "surrogateescape").replace(",","")
                if saleprice:
                    dllobj.Price = str(saleprice)
                else:
                    if 'pdp-product-price' in response.text:
                        price_path = r'E:\kcp_lazada_pricestock_price' + f'{sku}.html'
                        upright_main(sku_url, price_path)
                        print("price is not found -------    ")
                        time.sleep(2000)
                    else:
                        dllobj.Price = ''
            except Exception as e:
                print(Fore.RED + 'Error in Price == ', e)
                return None

            try:
            # todo stock,instock
                stock = skuinfos['stock']
                dllobj.Stock=str(stock)
                if stock:
                    # dllobj.Stock = str(stock)
                    if stock > 0:
                        dllobj.InStock = 'TRUE'
                        # dllobj.Stock = str(1)
                    else:
                        dllobj.InStock = 'FALSE'
                        # dllobj.Stock = str(0)
                else:
                    dllobj.Stock = '0'
                    dllobj.InStock = 'FALSE'
            except Exception as e:
                print(Fore.RED + 'Error in Stock or instock == ',e)

            try:
                # todo brand
                brand = comman_data['tracking']['brand_name']
                dllobj.Brand = brand
                dllobj.Input_Brand = brand
            except Exception as e:
                print(Fore.RED + 'Error in Brand == ',e)

        else:
            sku = cheapset
            dllobj.Seller_Name = ''
            dllobj.SKU_Url = sku_url
            dllobj.SKU_ID = sku
            dllobj.Variant_ID = ''
            dllobj.Price = ''
            dllobj.Input_Brand = ''
            dllobj.InStock = 'FALSE'
            dllobj.Stock = ''
            dllobj.Brand = ''

        # todo simple data
        if self.region=='ID':
            dllobj.id1 = str(id)
        elif id1==None:
            dllobj.id1='0'
        else:
            dllobj.id1 = str(id1)
        dllobj.cat_id = ''
        dllobj.Date = datetime.today().strftime('%m/%d/%Y')
        dllobj.Time = datetime.today().strftime('%H:%M:%S')
        dllobj.Country = self.region.upper()
        dllobj.status = "Done"
        dllobj.SIS = ''
        dllobj.Is_Competitor = 'NO'
        dllobj.SKU_Url = sku_url
        dllobj.htmlpath = path
        if self.region == 'ID':
            dllobj.Page_Url = ''
        else:
            dllobj.Page_Url = page_url

        dllobj.Retailer = 'Lazada'

        total_count += 1
        print(Fore.GREEN + f"======================{id}=======================================")
        # todo variation start
        variation_check = comman_data['productOption']['skuBase']['skus']
        # if variation_check == [] or len(variation_check)==1 or cheapset == sku:
        try:
            dllobj.isVariant = 'No'
            if cheapset == sku:
                error_msg = dllobj.QA_check()
                if error_msg == '':
                    update = dllobj.update_table(self.select_time_list)
                    if "pg_PriceStock_productdata" in update:
                        update_q = update.replace(f'pg_PriceStock_productdata_{old_td}_{self.select_time_list}',f'{self.new_table_name}')
                        self.cursor.execute(update_q)
                        self.con.commit()
                        print(Fore.GREEN + "!!!!!!!!!!  UPDATE SUCESSFULLY   !!!!!!!!!!!!!!!!!")
                else:
                    print("error mag==",error_msg)
        except Exception as e:
                print(Fore.RED + 'Error in inserting data ==', e)


        # else:
        #     for var in variation_check:
        #         #TODO VARIANT SKU_ID,VARIEANT_ID
        #         variant_sku_id = var['innerSkuId']
        #         dllobj.SKU_ID = variant_sku_id
        #         variant_id = str(variant_sku_id).split("-")[1]
        #         dllobj.Variant_ID = variant_id
        #
        #         #TODO VARIANT URL
        #         try:
        #             variant_url = var['pagePath']
        #             dllobj.SKU_Url = domain + variant_url
        #         except Exception as e:
        #             print(Fore.RED +'Error in variant url',e)
        #
        #         # TODO VARAINT PRICE
        #         if comman_data.get(split):
        #             try:
        #                 variant_price = comman_data['skuInfos'][variant_id]['price']['salePrice']['value']
        #                 dllobj.Price = str(variant_price)
        #             except Exception as e:
        #                 print(Fore.RED + 'Error in variant price', e)
        #         else:
        #             try:
        #                 variant_id = var['skuId']
        #                 variant_price = comman_data['skuInfos'][variant_id]['price']['salePrice']['value']
        #                 dllobj.Price = str(variant_price)
        #             except Exception as e:
        #                 print(Fore.RED + 'Error in variant price', e)
        #
        #
        #
        #         # TODO VARIANT STOCK,VARIANT AVAILABILITY
        #         try:
        #             # variant_stock = comman_data['skuInfos'][variant_id]['quantity']['text']
        #             variant_stock = comman_data['skuInfos'][variant_id]['stock']
        #             if variant_stock > 0:
        #                 dllobj.InStock = 'TRUE'
        #                 variant_stock = '1'
        #             else:
        #                 dllobj.InStock = 'FALSE'
        #                 variant_stock='0'
        #             # variant_stock = re.findall('[0-9]+', variant_stock)
        #             # variant_stock = ".".join(variant_stock)
        #             dllobj.Stock = str(variant_stock)
        #         except Exception as e:
        #             print(Fore.RED +'Error in variant stock and valiability',e)
        #             dllobj.InStock = 'FALSE'
        #
        #         try:
        #             print(sku)
        #             print(variant_sku_id)
        #             if variant_sku_id==sku:
        #                 dllobj.isVariant = 'Yes'
        #                 error_msg = dllobj.QA_check()
        #                 if error_msg == '':
        #                     update = dllobj.update_table(self.select_time_list)
        #                     if "pg_PriceStock_productdata" in update:
        #                         update_q = update.replace(f'pg_PriceStock_productdata_{old_td}_{self.select_time_list}',f'{self.new_table_name}')
        #                         self.cursor.execute(update_q)
        #                         self.con.commit()
        #                         print(Fore.GREEN + "!!!!!!!!!!  UPDATE SUCESSFULLY   !!!!!!!!!!!!!!!!!")
        #             elif not variant_sku_id==sku:
        #                 dllobj.isVariant = 'No'
        #                 dllobj.id1 = str(id)
        #                 error_msg = dllobj.QA_check()
        #                 if error_msg == '':
        #                     insert = dllobj.Insert_Query(self.select_time_list)
        #                     if "pg_PriceStock_productdata" in insert:
        #                         insert_q = insert.replace(f'pg_PriceStock_productdata_{old_td}_{self.select_time_list}', f'{self.new_table_name}')
        #                         self.cursor.execute(insert_q)
        #                         self.con.commit()
        #                         print(Fore.GREEN + "!!!!!!!!!!  Variation Inserted   !!!!!!!!!!!!!!!!!")
        #             else:
        #                 dllobj.isVariant = 'Yes'
        #                 error_msg = dllobj.QA_check()
        #                 if error_msg == '':
        #                     update = dllobj.update_table(self.select_time_list)
        #                     if "pg_PriceStock_productdata" in update:
        #                         update_q = update.replace(f'pg_PriceStock_productdata_{old_td}_{self.select_time_list}',f'{self.new_table_name}')
        #                         self.cursor.execute(update_q)
        #                         self.con.commit()
        #                         print(Fore.GREEN + "!!!!!!!!!!  UPDATE SUCESSFULLY   !!!!!!!!!!!!!!!!!")
        #         except Exception as e:
        #             print(Fore.RED ,e)
    def close(self, spider, reason):
        try:
            # new_table_name = f"pg_pricestock_productdata_{old_td}_{self.region}_{self.select_time_list}"
            prod_sql = f"SELECT * FROM {self.new_table_name} WHERE status='Pending'"
            print(prod_sql)
            self.cursor = spider.cursor
            self.cursor.execute(prod_sql)

            rows = self.cursor.fetchall()
            if rows == ():

                print('spider is close,...................')
                print('going on QA and make csv..............')
                from p_and_g_kcp_lazada.dll_export_csv import Export_Csv
                c = Export_Csv()
                c.export_csv(self.region,self.feed)

            else:
                print('some entries are pending')
        except Exception as e:
            print(e)
            logger.error('close spider error:{}'.format(e))

if __name__ == '__main__':
    from scrapy.cmdline import execute
    execute('scrapy crawl lazada_pdp -a region=MY -a feed=1264 -a start=1 -a end=10000000'.split())
    # execute('scrapy crawl lazada_pdp -a region=TH -a feed=1267 -a start=1 -a end=1313'.split())
    # execute('scrapy crawl lazada_pdp -a region=ID -a feed=1263 -a start=1 -a end=10000000'.split())
    # execute('scrapy crawl lazada_pdp -a region=VN -a feed=1268 -a start=1 -a end=10000000'.split())
    # execute('scrapy crawl lazada_pdp -a region=PH -a feed=1265 -a start=1 -a end=1000'.split())
    # execute('scrapy crawl lazada_pdp -a region=SG -a feed=1266 -a start=1 -a end=1000000000'.split())