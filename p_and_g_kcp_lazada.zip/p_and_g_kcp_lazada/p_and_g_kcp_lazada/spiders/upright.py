# import os
# import time
#
# from playwright.sync_api import Playwright, sync_playwright
#
# def upright_main(sku_url,path):
#     try:
#         with sync_playwright() as p:
#             browser = p.chromium.launch(channel="msedge", headless=False, slow_mo=50)
#             page = browser.new_page()
#             page.set_default_timeout(0)
#
#             page.goto(sku_url)
#             for i in range(5):  # make the range as long as needed
#                 page.mouse.wheel(0, 500)
#                 time.sleep(1)
#                 i += 1
#
#             response_txt = page.content()
#
#             try:
#                 if "var __moduleData__" in response_txt:
#                     with open(path, 'w', encoding='utf-8') as f:
#                         f.write(page.content())
#
#                 if os.path.exists(path):
#                     with open(path, 'r',encoding='utf-8' ) as f:
#                         page_content = f.read()
#             except Exception as e:
#                 print(e)
#
#             browser.close()
#
#             if "var __moduleData__" in page_content:
#                 return True
#             else:
#                 return False
#
#     except Exception as e:
#         print("Error in sel fun....-- ",e)
#
#
# main_price = ""
#             try:
#                 price = response.xpath('''//div[contains(@class, 'product-price')]//span[contains(@class, 'pdp-price')]//text()''').getall()
#                 if price:
#                     if len(price) == 2:
#                         main_price = price[0]
#                         base_price = price[1]
#                     else:
#                         main_price = price[0]
#                         base_price = ""
#                 else:
#                     base_price = ""
#                     print("Price not found--- ")
#                     os.remove(path)
#                     # return None
#             except Exception as e:
#                 base_price = ""
#                 os.remove(path)
#                 print("Error  in price---- ", e)
#                 # return None
#
#             if main_price:
#                 main_price = re.sub("[^.,0-9]", "", main_price)
#             if base_price:
#                 base_price = re.sub("[^.,0-9]", "", base_price)
#
#             if main_price == "":
#                 currency = ""
#             else:
#                 currency = currency
#             if base_price == "":
#                 currency = ""
#
#             # todo - discounts
#             try:
#                 discount = response.xpath(
#                     '''//div[contains(@class, 'product-price')]//span[contains(@class, 'discount')]//text()''').get()
#                 if discount:
#                     discount = str(discount).replace("OFF", '').replace("off", '')
#                 else:
#                     discount = response.xpath(
#                         '''//div[@class="pdp-mod-product-price"]//div//span[@class="pdp-product-price__discount"]//text()''').get()
#                     if discount:
#                         discount = str(discount).replace("OFF", '').replace("off", '')
#                     else:
#                         discount = ""
#
#                 discount = re.sub("[^.0-9 ]", "", discount)
#             except Exception as e:
#                 print("Error in discounts--- ", e)
#                 # return None
#
#             # todo - variant name
#             try:
#                 variant_name = response.xpath(
#                     '''//div[@class="pdp-block module"]//div[@class="sku-prop-content-header"]//span[@class="sku-name "]//text()''').get()
#                 if variant_name:
#                     variant_name = variant_name
#                 else:
#                     variant_name = ""
#             except Exception as e:
#                 print("Error in variant name-- ", e)
#
#             # todo - stock_status
#             try:
#                 stock = response.xpath(
#                     '''//div[@class="pdp-addon-label"]//span[@class="addon-label-text"]//text()''').get()
#                 if stock:
#                     if "out of stock" in stock.lower():
#                         Instock = '0'
#                         stock_count = '0'
#                         stock_status = "OOS"
#
#                     elif stock:
#                         stock_count = (re.sub("[<.a-z,A-Z]", "", stock)).strip()
#                         if int(stock_count) == 0:
#                             Instock = '0'
#                             stock_status = "OOS"
#                         elif int(stock_count) >= 1:
#                             Instock = '1'
#                             stock_status = "IN STOCK"
#                         else:
#                             Instock = ""
#                             stock_status = ""
#                             stock_count = ""
#                     else:
#                         if "ADD TO CART" in main_data:
#                             stock_count = "1"
#                             Instock = '1'
#                             stock_status = "IN STOCK"
#                         else:
#                             stock_count = ""
#                             Instock = ""
#                             stock_status = ""
#                 else:
#                     stock = response.xpath('''//button[contains(@class,"add-to-cart-buy-now-btn")]''').get()
#                     if stock:
#                         stock_count = "1"
#                         Instock = '1'
#                         stock_status = "IN STOCK"
#                     else:
#                         if "ADD TO CART" in main_data:
#                             stock_count = "1"
#                             Instock = '1'
#                             stock_status = "IN STOCK"
#                         else:
#                             stock_count = ""
#                             Instock = ""
#                             stock_status = ""
#             except Exception as e:
#                 print("Error  in stock---- ", e)
#                 return None
#
#             # todo - sellername
#             try:
#                 seller_name = response.xpath('''//div[@class="redmart-seller__logo"]''').get()
#                 if seller_name:
#                     seller_name = "redmart"
#                 else:
#                     seller_name = response.xpath('''//div[@class="seller-name__detail"]//a/text()''').get()
#                     if seller_name:
#                         seller_name = seller_name
#                     else:
#                         seller_name = ""
#             except Exception as e:
#                 print("Error in seller name---> ",e)
#                 return None
#
#             # todo - rating
#             try:
#                 rating = response.xpath('''//div[@class="score"]//span[@class="score-average"]//text()''').get()
#                 if rating:
#                     rating = rating
#                 else:
#                     rating = ""
#             except Exception as e:
#                 print("Error in rating-- ", e)
#                 return None
#
#             # todo - review
#             try:
#                 review = response.xpath('''//div[@class="count"]/text()''').get()
#                 if review:
#                     review = review
#                 else:
#                     review = ""
#
#                 review = str(re.sub("[<.a-z,A-Z]", "", review)).strip()
#             except Exception as e:
#                 print("Error in rating-- ", e)
#                 return None
#
#             # todo - category
#             try:
#                 category = response.xpath('''//div[@data-spm="breadcrumb"]//span[@class="breadcrumb_item_text"]//span//text()''').getall()
#                 if category:
#                     category = category[:-1]
#                     category = "|".join(category)
#                 else:
#                     category = ""
#             except Exception as e:
#                 print("Error in --- category", e)
#                 return None
#
#             if "emoneychart" in maintable_name:
#                 # todo - Price_Pad calculation
#                 try:
#                     Price_Pad = float(main_price) / (int(Size) * int(Pad))
#                     Price_Pad = round(Price_Pad, 4)
#                 except:
#                     try:
#                         Price_Pad = int(main_price) / (int(Size) * int(Pad))
#                         Price_Pad = round(Price_Pad, 4)
#                     except Exception as e:
#                         print("Error in calculation of price pd... ---- ", e)
#             else:
#                 Price_Pad = ""