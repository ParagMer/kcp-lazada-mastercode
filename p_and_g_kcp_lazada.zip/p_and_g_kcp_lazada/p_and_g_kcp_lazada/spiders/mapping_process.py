import scrapy

from p_and_g_kcp_lazada.pipelines import *
from p_and_g_kcp_lazada.config import *

class KcpLazadaSpider(scrapy.Spider):
    name = 'mapping_lazada'

    def __init__(self, start='', end='', region=''):
        self.start = start
        self.end = end
        self.region = region

    def start_requests(self):
        self.cursor, self.con, self.new_table_name = PAndGKcpLazadaPipeline.create_table(self,self.region)

        try:
            selectquery = f"select `sku id`,`sku name`,id from pg_web_availability_inputs_{self.region}"
            self.cursor.execute(selectquery)
            table = self.cursor.fetchall()
            for row in table:
                sku_id = row[0]
                sku_name = row[1]
                id = row[2]
                selectquery2 = f"select sku_id from {self.new_table_name}"
                self.cursor.execute(selectquery2)
                table2 = self.cursor.fetchall()
                if (sku_id,) not in table2:
                    try:
                        print(Fore.CYAN + f'----------------------------------------inputs id no. = {id}---------------------------------------')
                        insertquery = f'''INSERT INTO {self.new_table_name} (status_1,sku_id,sku_name) VALUES ('Done','{sku_id}','{sku_name}')'''.replace("'s", 's').replace("'m","m")
                        insertquery = c_replace(insertquery)
                        self.cursor.execute(insertquery)
                        self.con.commit()
                    except Exception as e:
                        print(sku_id)
                        print(Fore.RED + 'Error in inserting data ==', e)
                else:
                    continue

            yield scrapy.Request(url='https://www.google.com',callback=self.parse)
        except Exception as e:
            print(Fore.RED + 'Error while fetching url from inputs table --- ', e)
    def parse(self, response, **kwargs):
        print(Fore.GREEN + '!!!!!!!!!!!!!!!!Mapping Sucessfully Done!!!!!!!!!!!!!!!!!!!!!!!!!')
if __name__ == '__main__':
    from scrapy.cmdline import execute
    execute('scrapy crawl mapping_lazada -a region=SG -a start=1 -a end=3'.split())