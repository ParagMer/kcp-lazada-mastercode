import json
import re
import sys
import time
import requests
import scrapy
import selenium
from colorama import init,Fore , Back, Style
from logger import logger

init(autoreset=True,convert=True)
from scrapy import Selector

from p_and_g_kcp_lazada.pipelines import *
from p_and_g_kcp_lazada.config import *

class KcpLazadaSpider(scrapy.Spider):
    name = 'input_brand'

    def __init__(self,start='',end='',region=''):
        self.start = start
        self.end = end
        self.region = region


    def start_requests(self):
        try:
            self.dir , self.select_time_list = makeHTML(region=self.region)

            self.cursor , self.con , self.new_table_name = PAndGKcpLazadaPipeline.create_table(self, self.region)

            self.region =self.region.upper()
            if self.region == "ID":
                update  = f'update {self.new_table_name} set status_1="Done" where status="Pending"'
                self.cursor.execute(update)
                self.con.commit()
            else:
                '---'

            sqltablecheck = f'SELECT htmlpath,id1,isVariant,Variant_ID,`DATE`,`TIME`,Country,SKU_ID,SKU_Name,SKU_Url,Seller_Name,Page_Url,Price,InStock,Stock,Brand,Retailer FROM {self.new_table_name} where Input_brand="others" and ID BETWEEN {self.start} AND {self.end}'
            self.cursor.execute(sqltablecheck)
            rep = self.cursor.fetchall()
            for i in rep:
                htmlpath = i[0]
                id1 = i[1]
                isVariant = i[2]
                Variant_ID = i[3]
                DATE = i[4]
                TIME = i[5]
                Country = i[6]
                SKU_ID = i[7]
                SKU_Name = i[8]
                SKU_Url = i[9]
                Seller_Name = i[10]
                Page_Url = i[11]
                Price = i[12]
                InStock = i[13]
                Stock = i[14]
                Brand = i[15]
                Retailer = i[16]
                print(f'!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')

                dllobj.htmlpath = str(htmlpath)
                dllobj.id1 = str(id1)
                dllobj.isVariant = str(isVariant)
                dllobj.Variant_ID = str(Variant_ID)
                dllobj.Date = str(DATE)
                dllobj.Time = str(TIME)
                dllobj.Country = str(Country)
                dllobj.SKU_ID = str(SKU_ID)
                dllobj.SKU_Name = str(SKU_Name)
                dllobj.SKU_Url = str(SKU_Url)
                dllobj.Seller_Name = str(Seller_Name)
                dllobj.Page_Url = str(Page_Url)
                dllobj.Price = str(Price)
                dllobj.InStock = str(InStock)
                dllobj.Stock = str(Stock)
                dllobj.Brand = str(Brand)
                dllobj.Retailer = str(Retailer)
                dllobj.status='Done'

                error_msg = dllobj.QA_check()
                if error_msg == '':
                    update = dllobj.update_table(self.select_time_list)
                    if "pg_PriceStock_productdata" in update:
                        update_q = update.replace(f'pg_PriceStock_productdata_{old_td}_{self.select_time_list}',
                                                  f'{self.new_table_name}')
                        print(update_q)
                        self.cursor.execute(update_q)
                        self.con.commit()
                        print(Fore.GREEN + "!!!!!!!!!!  UPDATE SUCESSFULLY   !!!!!!!!!!!!!!!!!")
                else:
                    print("error mag==", error_msg)


        except Exception as e:
            print("Error in start request method ...",e)

    # def parse(self, response, **kwargs):
    #     sku_url = response.meta.get('sku_url')
    #     htmlpath = response.meta.get('htmlpath')
    #     id1 = response.meta.get('id1')
    #     isVariant = response.meta.get('isVariant')
    #     Variant_ID = response.meta.get('Variant_ID')
    #     DATE = response.meta.get('DATE')
    #     TIME = response.meta.get('TIME')
    #     Country = response.meta.get('Country')
    #     SKU_ID = response.meta.get('SKU_ID')
    #     SKU_Name = response.meta.get('SKU_Name')
    #     SKU_Url = response.meta.get('SKU_Url')
    #     Seller_Name = response.meta.get('Seller_Name')
    #     Page_Url = response.meta.get('Page_Url')
    #     Price = response.meta.get('Price')
    #     InStock = response.meta.get('InStock')
    #     Stock = response.meta.get('Stock')
    #     Brand = response.meta.get('Brand')
    #     Retailer = response.meta.get('Retailer')


if __name__ == '__main__':
    from scrapy.cmdline import execute
    # execute('scrapy crawl input_brand -a region=TH -a start=1 -a end=100000000'.split())
    # execute('scrapy crawl input_brand -a region=SG -a start=1 -a end=1000000000'.split())
    execute('scrapy crawl input_brand -a region=VN -a start=1 -a end=17071000000'.split())
    # execute('scrapy crawl input_brand -a region=MY -a start=1 -a end=80'.split())
    # execute('scrapy crawl input_brand -a region=PH -a start=1 -a end=17071000000'.split())
    # execute('scrapy crawl input_brand -a region=ID -a start=1 -a end=520'.split())
