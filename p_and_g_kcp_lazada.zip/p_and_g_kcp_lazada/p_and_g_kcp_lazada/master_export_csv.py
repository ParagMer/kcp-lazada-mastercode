import subprocess
from datetime import datetime
import csv
import datetime
# from os import subprocess
import shutil
import time
import pymysql
import pandas as pd
import requests
# import today as today
from numpy.ma import count
from p_and_g_kcp_lazada.config import *


# check directory exists or not and make csv file in the bellow directory
class Export_Csv:

    def export_csv(self,region):
        try:
            # region= self.region

            region = region
            date = datetime.now().strftime('%m-%d-%Y')
            db_name = "p_and_g_kcp_lazada_all_bycategory"
            Csv_Output_File_Path = "G:\\Daily Scheduler\\0. P&G\\0. CSV\\KCP"+ "\\"  + time.strftime('%Y') + "\\" + time.strftime("%m") + "\\" + time.strftime("%d")
            print(Csv_Output_File_Path)
            try:
                if not os.path.exists(Csv_Output_File_Path):
                    os.makedirs(Csv_Output_File_Path)
            except:
                 pass

            self.con = pymysql.connect(host=db_host, user=db_user, password=db_passwd, database=db_name, autocommit=True, use_unicode=True,charset="utf8")
            self.cursor = self.con.cursor()
            con= self.con

            country = region.upper()
            select_time = f"SELECT Timezone FROM timezone where country='{country}'"
            self.cursor.execute(select_time)
            select_time_list = [column for column in self.cursor.fetchall()][0][0]

            print(select_time_list)

            new_table_name = f"pg_pricestock_productdata_{old_td}_{region}_{select_time_list}"
            # select_time_list='1630pm'
            # new_table_name = f"pg_pricestock_productdata_{old_td}_{region}_{select_time_list}"

            # if region=='id' or region=='vn':
            #     try:
            #         Delete_qry = f'DELETE FROM {new_table_name} WHERE SKU_ID IN (SELECT sku_id FROM discontinue_skuid_{region})'
            #         print(Delete_qry)
            #         self.cursor.execute(Delete_qry)
            #         con.commit()
            #     except Exception as E:
            #         print(E)
            # else:
            #     ...
            new_table_name = f"pg_pricestock_productdata_{old_td}_{region}_{select_time_list}"
            select_time_list = str(select_time_list).replace("am", "HR").replace("pm", "HR").replace("AM","HR").replace("PM","HR")

            sql_query = pd.read_sql_query(f'select `Date`,`Time`,`Country`,`Input_Brand`,`SKU_ID`,`Variant_ID`,`SKU_Name`,`SKU_Url`,`Seller_Name`,`Page_Url`,`SIS`,`Price`,`InStock` as `In Stock`,`Stock`,`Brand`,`Retailer` from {new_table_name} where status!="Pending"  Group BY SKU_ID',con)

            print(sql_query)
            df = pd.DataFrame(sql_query)
            df.to_excel(f'{Csv_Output_File_Path}/KCP_Lazada_{region.upper()}_PriceStock_{date}_{select_time_list}.xlsx',sheet_name="PriceStock", index=False,encoding='utf-8-sig')
            print("......................File Created.........................")
        except Exception as e:
            print("ERROR",e)


c = Export_Csv()
c.export_csv("vn")
