import pymysql
import time
import os
from mymodules._common_ import c_replace
# Today_date = str(open(r'D:\Yash_Prajapati\today_date.txt', 'r').read())
# Today_date=c_replace(Today_date)
from p_and_g_kcp_lazada.config import *
from p_and_g_kcp_lazada.spiders.category import *
import numpy as np

def Competition_data(region):
    region_u = region
    region = region.upper()
    p,select_time_list,q = makeHTML(region,'')

    db_name=f'p_and_g_kcp_lazada_all_bycategory'
    # db_host=input("Enter the Host_Name:")
    db_host='192.168.1.235'
    # db_data_table=input("Enter the Database_Table_Name:")
    db_data_table=f"pg_pricestock_productdata_{old_td}_{region}_{select_time_list}"
    db_passwd="xbyte"
    db_user="root"


    bat_path = 'D:\BAT_File'

    try:
        if not os.path.exists(bat_path):
            os.makedirs(bat_path)
    except Exception as e:
        print('exception in makedir config file error: ', e)

    con = pymysql.connect(host=db_host, user=db_user, password=db_passwd)
    db_cursor = con.cursor()
    create_db = f"create database if not exists {db_name} CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci"
    db_cursor.execute(create_db)
    con = pymysql.connect(host=db_host, user=db_user, password=db_passwd, database=db_name, autocommit=True)
    cursor = con.cursor()
    connection_string = f"server={db_host};uid={db_user};pwd={db_passwd};database={db_name}"


    # sql_query = f"SELECT * FROM category WHERE market='{region}' and Status='pending'"

    sql_query=f"SELECT * FROM {db_data_table} WHERE Status='pending'"

    print(sql_query)
    try:
        cursor.execute(sql_query)
    except Exception as e:
        print(e)
    result = cursor.fetchall()
    core_list = [column for column in result]
    C_ids = []
    for itm in core_list:
        id = itm[0]
        C_ids.append(id)

    # Spider_Name=input("Enter the Spider Name:")
    Spider_Name='lazada_pdp'
    # Store_Name=input("Enter the Exe Name:")
    Store_Name=f'pdp_{region}'
    print(C_ids,type(C_ids))
    temp=0
    l = len(C_ids)
    start = True

    n = int(input("Enter the Part:"))
    d=round(l/n)
    x_ids =np.array_split(C_ids,n)

    path = f'E:\\Parag_Mer\\Training\\p_and_g_kcp_lazada\\p_and_g_kcp_lazada\\spiders\\pdp_{region}.bat'

    try:
        with open(path,'r+') as f1:
            f1.truncate()
    except Exception as e:
        print(e)
    pending_bat = []
    with open( path, 'a') as f:
        f.write(f'taskkill /im pdp_{region_u}.exe')
        f.write('\n')
        f.close()
    for parts in x_ids:
        with open(path,'a') as f:
            f.write(f'start {Store_Name} crawl {Spider_Name} -a region={region} -a start={parts[0]} -a end={parts[-1]}')
            f.write('\n')
            f.close()

region=input("Enter the region:")
# region="sg"
region= Competition_data(region)


