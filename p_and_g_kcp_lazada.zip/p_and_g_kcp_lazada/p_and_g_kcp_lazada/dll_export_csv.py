"""coding is export csv form export csv referen in dowload file export csv.py
QA file
"""
import time

from p_and_g_kcp_lazada.config import *


class Export_Csv:

    def export_csv(self,region,feed):
        try:

            HTML_web_availibility,select_time_list,feed = makeHTML(region,feed)
            print(HTML_web_availibility)

            con = pymysql.connect(host=db_host, user=db_user, password=db_passwd, database=db_name)
            cursor = con.cursor()

            print(select_time_list)

            # dllobj.create_folder('E', 'Lazada', 'Daily',f'{region}',f'{select_time_list}',feed)
            "dllobj.create_folder('D', 'shopee', 'Daily',f'{region}',f'{select_time_list}',feed)"
            select_time_list = f"{region}_{select_time_list}"


            error_msg_csv = dllobj.ExportExcelPriceStock('datasource=192.168.1.235;username=root;password=xbyte;database='+db_name+';ssl mode=none;',select_time_list)
            print(error_msg_csv)
            if error_msg_csv == "":
                print('File Created...:')
            else:
                print(error_msg_csv)
        except Exception as e:
            print('Error in creating Excel throughdll',e)



# region = 'my'
# c = Export_Csv()
# c.export_csv(region)
