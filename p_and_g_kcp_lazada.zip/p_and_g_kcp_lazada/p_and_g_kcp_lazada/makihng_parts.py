import MySQLdb as pymysql
import numpy as np
part_count = 30


from datetime import datetime
table_date = datetime.now().strftime('%Y%m%d')

with open(r'E:\Parag Mer\working\P&G\p_and_g_kcp_lazada\p_and_g_kcp_lazada\lazada_krushil.txt','r') as f:
    file = f.read()
file = file.split('\n')
region = file[1].replace('tablename =','').split('_')[-2]
spider_name = "lazada_pdp"
file_name = f"pdp_{region}.bat"

db_host = '192.168.1.235'
db_user = 'root'
db_passwd = 'xbyte'
db_name = file[0].replace('db_name = ','')
maintable_name = file[1].replace('tablename =','')

database = pymysql.connect(host=db_host, user=db_user, password=db_passwd, database=db_name)
cursor = database.cursor()

sql_query=f'''SELECT Id FROM {maintable_name} WHERE status='Pending' '''

cursor.execute(sql_query)
results = cursor.fetchall()
rows = len(results)
check = rows/int(part_count)
core_list = [column for column in results]
C_ids = []
for itm in core_list:
    id = itm[0]
    C_ids.append(id)
temp=0
l = len(C_ids)

# n = int(input("Enter the Part:"))
n = part_count
d=round(l/n)
x_ids =np.array_split(C_ids,n)
path =  'E:\Parag Mer\working\P&G\p_and_g_kcp_lazada\p_and_g_kcp_lazada\spiders' +'\\'+ file_name
try:
    with open(path, 'r+') as f1:
        f1.truncate()
except Exception as  e:
    print(e)

with open( path, 'a') as f:
    f.write(f'taskkill /im pdp_{region.lower()}.exe')
    f.write('\n')
    f.close()
for parts in x_ids:
    with open(path,'a') as f:
        f.write(f'start pdp_{region.lower()} crawl {spider_name} -a region={region.upper()} -a start={parts[0]} -a end={parts[-1]}')
        f.write('\n')
        f.close()