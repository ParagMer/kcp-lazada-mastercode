# url = f'http:{all_urls}'
#
# # todo page_url,cheaspest(sku_id),listprice,saleprice

# dllobj.Page_Url = url
# cheapest_sku = i['cheapest_sku']
# liprice = i['priceShow']
# liprice = re.findall('[0-9]+', liprice)
# liprice = ".".join(liprice)
# if liprice > '0':
#     dllobj.InStock = 'True'
# else:
#     dllobj.InStock = 'False'
# name = i['name']
# sellerName = i['sellerName']
#
# dllobj.Seller_Name = sellerName
# dllobj.SKU_Name = name
# dllobj.SKU_Url = url
# dllobj.Price = str(liprice)
# dllobj.SKU_ID = cheapest_sku
# dllobj.Date = datetime.today().strftime('%m/%d/%Y')
#
# # todo extra
# dllobj.id1 = "0"
# dllobj.Country = self.region
# dllobj.Retailer = 'Lazada'
# dllobj.status = 'Done'
#
# # todo htmlpath
# dllobj.htmlpath = self.dir
#
# print('page url ---', url)
#
# try:
#     error_msg = dllobj.QA_check()
#     if error_msg == '':
#         print(dllobj.Insert_Query(self.select_time_list))
#         update = dllobj.update_table(self.select_time_list)
#         if "pg_PriceStock_productdata" in update:
#             update_q = update.replace(f'pg_PriceStock_productdata_{old_td}_{self.select_time_list}',f'{self.new_table_name}').replace('status','status_1')
#             print(update_q)
#             self.cursor.execute(update_q)
#             self.con.commit()
# except Exception as e:
#     print(Fore.RED + 'Error in inserting data ==', e)

