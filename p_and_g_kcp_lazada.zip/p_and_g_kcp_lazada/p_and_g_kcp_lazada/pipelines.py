# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
import pymysql
from mymodules._common_ import c_replace

from p_and_g_kcp_lazada.config import *


class PAndGKcpLazadaPipeline:
    def create_table(self, region):
        con = pymysql.connect(host=db_host, user=db_user, password=db_passwd)
        db_cursor = con.cursor()
        create_db = f"create database if not exists {db_name} CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci"
        db_cursor.execute(create_db)
        con = pymysql.connect(host=db_host, user=db_user, password=db_passwd, database=db_name, autocommit=True)
        cursor = con.cursor()

        select_timezone = f"""select Timezone from timezone where Country='{region.upper()}'"""
        cursor.execute(select_timezone)
        select_time_list = [column for column in cursor.fetchall()][0][0]
        print(select_time_list)

        # connection_string = "timezone=" + select_time_list + "server=192.168.1.70   ;uid=root;pwd=xbyte;database=" + db_name + ";ssl mode=none;"
        new_table_name = f"pg_pricestock_productdata_{old_td}_{region}_{select_time_list}"

        create_table = dllobj.create_table(select_time_list)
        create_table = c_replace(create_table).replace(f"pg_PriceStock_productdata_{old_td}_{select_time_list}",f"pg_PriceStock_productdata_{old_td}_{region}_{select_time_list}")

        try:
            query = [i for i in create_table.split(';') if i]
            for i in query:
                cursor.execute(i)
                con.commit()
        except Exception as e:
            print('Dll table making issue.:', e)

            # TODO INSERT DATA INTO NEW TABLE

        try:
            select = f"""SELECT * FROM {new_table_name}"""
            cursor.execute(select)
            result = cursor.fetchall()
            new_input_table = f"pg_web_availability_inputs_{region}"
            append_or_not = ''
            if result == ():
                append_or_not = input('Do you want to insert last urls ==').lower()
                if append_or_not == 'yes':
                    if region == 'ID':
                        insert_data = f"INSERT INTO {new_table_name} (SKU_ID,SKU_Name,SKU_Url) (SELECT SKU_ID,SKU_Name,SKU_Url FROM {new_input_table})"
                    elif region == 'VN':
                        insert_data = f"INSERT INTO {new_table_name} (id1,cat_id,htmlpath_2,isVariant,Variant_ID,Country,Input_Brand,SKU_ID,SKU_Name,SKU_Url,Seller_Name,Page_Url,Brand,Retailer) (SELECT id1,cat_id,htmlpath_2,isVariant,Variant_ID,Country,Input_Brand,SKU_ID,SKU_Name,SKU_Url,Seller_Name,Page_Url,Brand,Retailer FROM pg_pricestock_productdata_20221111_{region}_1100)"
                    else:
                        insert_data = f"INSERT INTO {new_table_name} (id1,cat_id,htmlpath_2,isVariant,Variant_ID,Country,Input_Brand,SKU_ID,SKU_Name,SKU_Url,Seller_Name,Page_Url,Brand,Retailer) (SELECT id1,cat_id,htmlpath_2,isVariant,Variant_ID,Country,Input_Brand,SKU_ID,SKU_Name,SKU_Url,Seller_Name,Page_Url,Brand,Retailer FROM pg_pricestock_productdata_20221111_{region}_0100)"
                    # insert_data = f"INSERT INTO {new_table_name} (id1,cat_id,htmlpath_2,isVariant,Variant_ID,Country,Input_Brand,SKU_ID,SKU_Name,SKU_Url,Seller_Name,Page_Url,Brand,Retailer) (SELECT id1,cat_id,htmlpath_2,isVariant,Variant_ID,Country,Input_Brand,SKU_ID,SKU_Name,SKU_Url,Seller_Name,Page_Url,Brand,Retailer FROM pg_pricestock_productdata_20221007_{region}_0900am)"
                    print(insert_data)
                    cursor.execute(insert_data)
                    con.commit()
                    print("Data Inserted.........")
            else:
                ''

        except Exception as e:
            print('Issuee in insert data.:', e)

        return cursor, con, new_table_name, append_or_not


    def create_table_pdp(self, region):
        con = pymysql.connect(host=db_host, user=db_user, password=db_passwd)
        db_cursor = con.cursor()
        create_db = f"create database if not exists {db_name} CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci"
        db_cursor.execute(create_db)
        con = pymysql.connect(host=db_host, user=db_user, password=db_passwd, database=db_name, autocommit=True)
        cursor = con.cursor()

        select_timezone = f"""select Timezone from timezone where Country='{region.upper()}'"""
        cursor.execute(select_timezone)
        select_time_list = [column for column in cursor.fetchall()][0][0]
        print(select_time_list)

        # connection_string = "timezone=" + select_time_list + "server=192.168.1.70   ;uid=root;pwd=xbyte;database=" + db_name + ";ssl mode=none;"
        new_table_name = f"pg_pricestock_productdata_{old_td}_{region}_{select_time_list}"

        create_table = dllobj.create_table(select_time_list)
        create_table = c_replace(create_table).replace(f"pg_PriceStock_productdata_{old_td}_{select_time_list}",f"pg_PriceStock_productdata_{old_td}_{region}_{select_time_list}")

        try:
            query = [i for i in create_table.split(';') if i]
            for i in query:
                cursor.execute(i)
                con.commit()
        except Exception as e:
            print('Dll table making issue.:', e)

            # TODO INSERT DATA INTO NEW TABLE

        try:
            select = f"""SELECT * FROM {new_table_name}"""
            cursor.execute(select)
            result = cursor.fetchall()
            new_input_table = f"pg_web_availability_inputs_{region}"
            # append_or_not = ''
            if result == ():
                append_or_not = input('Do you want to insert last urls ==').lower()
                if append_or_not == 'yes':
                    if region == 'ID':
                        insert_data = f"INSERT INTO {new_table_name} (SKU_ID,SKU_Name,SKU_Url) (SELECT SKU_ID,SKU_Name,SKU_Url FROM {new_input_table})"
                    elif region == 'VN':
                        insert_data = f"INSERT INTO {new_table_name} (SKU_ID,SKU_Name,SKU_Url) (SELECT SKU_ID,SKU_Name,SKU_Url FROM {new_input_table})"
                    else:
                        insert_data = f"INSERT INTO {new_table_name} (SKU_ID,SKU_Name,SKU_Url) (SELECT SKU_ID,SKU_Name,SKU_Url FROM {new_input_table})"
                    insert_data = f"INSERT INTO {new_table_name} (id1,cat_id,htmlpath_2,isVariant,Variant_ID,Country,Input_Brand,SKU_ID,SKU_Name,SKU_Url,Seller_Name,Page_Url,Brand,Retailer) (SELECT id1,cat_id,htmlpath_2,isVariant,Variant_ID,Country,Input_Brand,SKU_ID,SKU_Name,SKU_Url,Seller_Name,Page_Url,Brand,Retailer FROM pg_pricestock_productdata_20221007_{region}_0900am)"
                    print(insert_data)
                    cursor.execute(insert_data)
                    con.commit()
                    print("Data Inserted.........")
                else:
                    ''

        except Exception as e:
            print('Issuee in insert data.:', e)

        return cursor, con, new_table_name