# dllobj.isVariant = 'yes'
# id = ''
# try:
#     for_variation = variation_check[0]
#     innerSkuId = comman_data['productOption']['skuBase']
#     inner_sku = innerSkuId['skus'][0]['innerSkuId']
#     print(inner_sku)
#     print(sku)
#     if inner_sku == sku:
#         dllobj.isVariant = 'No'
#         pass
#     else:
#         color_append = []
#         sku_append = []
#         for i in for_variation['values']:
#             a = i['name']
#             a = "".join(a)
#             color_append.append(a)
#         for j in innerSkuId['skus']:
#             a = j['innerSkuId']
#             a = "".join(a)
#             sku_append.append(a)
#
#         res = {}
#         for key in color_append:
#             for value in sku_append:
#                 res[key] = value
#                 sku_append.remove(value)
#                 break
#             print(res)
#
#         for key, value in res.items():
#             dllobj.SKU_ID = value
#             try:
#                 error_msg = dllobj.QA_check()
#                 if error_msg == '':
#                     print(dllobj.Insert_Query(select_time_list))
#                     print(select_time_list)
#                     insert_q = dllobj.Insert_Query(select_time_list)
#                     if "pg_PriceStock_productdata" in insert_q:
#                         insert_q = insert_q.replace(f'pg_PriceStock_productdata_{old_td}_{select_time_list}',f'{new_table_name}')
#                     print(insert_q)
#                     cursor.execute(insert_q)
#                     con.commit()
#             except Exception as e:
#                 print(Fore.RED + 'Error in inserting data ==', e)
#
# except Exception as e:
#     exception_type, exception_object, exception_traceback = sys.exc_info()
#     line_number = exception_traceback.tb_lineno
#     print(Fore.RED + 'Error in variation block -- ', e, line_number)
# # TODO VARIATION END

# # todo variation start
# variation_check = comman_data['productOption']['skuBase']['properties']
# if variation_check == []:
#     try:
#         dllobj.isVariant='No'
#         error_msg = dllobj.QA_check()
#         if error_msg == '':
#             update = dllobj.update_table(select_time_list)
#             if "pg_PriceStock_productdata" in update:
#                 update_q = update.replace(f'pg_PriceStock_productdata_{old_td}_{select_time_list}',f'{new_table_name}')
#                 cursor.execute(update_q)
#                 con.commit()
#     except Exception as e:
#         print(Fore.RED + 'Error in inserting data ==', e)
# else:
#     try:
#         for_variation = variation_check[0]
#         innerSkuId = comman_data['productOption']['skuBase']
#         inner_sku = innerSkuId['skus'][0]['innerSkuId']
#         if inner_sku == sku:
#             dllobj.isVariant = 'No'
#             pass
#         else:
#             color_append = []
#             sku_append = []
#             for i in for_variation['values']:
#                 a = i['name']
#                 a = "".join(a)
#                 color_append.append(a)
#             for j in innerSkuId['skus']:
#                 a = j['innerSkuId']
#                 a = "".join(a)
#                 sku_append.append(a)
#
#             res = {}
#             for key in color_append:
#                 for value in sku_append:
#                     res[key] = value
#                     sku_append.remove(value)
#                     break
#                 print(res)
#
#             for key, value in res.items():
#                 dllobj.SKU_ID = value
#                 try:
#                     error_msg = dllobj.QA_check()
#                     if error_msg == '':
#                         print(dllobj.Insert_Query(select_time_list))
#                         print(select_time_list)
#                         insert_q = dllobj.Insert_Query(select_time_list)
#                         if "pg_PriceStock_productdata" in insert_q:
#                             insert_q = insert_q.replace(f'pg_PriceStock_productdata_{old_td}_{select_time_list}',f'{new_table_name}')
#                         print(insert_q)
#                         cursor.execute(insert_q)
#                         con.commit()
#                 except Exception as e:
#                     print(Fore.RED + 'Error in inserting data ==', e)
#
#     except Exception as e:
#         exception_type, exception_object, exception_traceback = sys.exc_info()
#         line_number = exception_traceback.tb_lineno
#         print(Fore.RED + 'Error in variation block -- ', e, line_number)
# TODO VARIATION END