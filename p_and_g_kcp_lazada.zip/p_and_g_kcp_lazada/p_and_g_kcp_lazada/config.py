import json
import random
import time

import clr
import os
from datetime import datetime

import pandas as pd
import pymysql
import requests
from colorama import Fore,init
init(autoreset=True)

old_td = datetime.now().strftime('%Y%m%d')
date = datetime.today().strftime('%Y_%m_%d')
now = datetime.now()

current_time = now.strftime("%H:%M:%S")
try:
    # val = clr.AddReference("\\\\192.168.1.199\\d\\DLL\\P_and_G_Project_Combine_DLL.dll")
    # val=str(val).replace("\\\\","//")
    clr.AddReference(r"E:\Daily Scheduler\0. P&G\P_and_G_Project_Combine_DLL.dll")
    from P_and_G_Project_Combine_DLL import PG_PriceStock_DLL_Project
    dllobj = PG_PriceStock_DLL_Project()
except Exception as e:
    print(e)

db_host = '192.168.1.235'
db_user = 'root'
db_passwd = 'xbyte'
db_name = 'p_and_g_kcp_lazada_all_bycategory'
db_input_sku = 'category'
db_product_table = f'input_sku_id'
db_timezone_table = f'timezone'


database = pymysql.connect(host=db_host, user=db_user, password=db_passwd, database=db_name,autocommit=True,use_unicode=True, charset="utf8")
sqlcommand = database.cursor()

def makeHTML(region,feed):

    if region == 'ID':
        feed = '1263'
    elif region == 'MY':
        feed = '1264'
    elif region == 'PH':
        feed = '1265'
    elif region == 'SG':
        feed = '1266'
    elif region == 'TH':
        feed = '1267'
    elif region == 'VN':
        feed = '1268'
    else:
        return None

    select_timezone = f"""select Timezone from timezone where Country='{region.upper()}'"""
    sqlcommand.execute(select_timezone)
    select_time_list = [column for column in sqlcommand.fetchall()][0][0]
    str_web_folder = dllobj.create_folder('E', 'lazada', 'Daily',f'{region}',f'{select_time_list}',feed)
    'create_folder(string drive, string store_name, string frequency, string Country_Code, string timezone)'
    if str_web_folder == "":
        HTML_web_availibility = dllobj.html_folder_path + '\\'
        csv_web_availibility_path = dllobj.csv_filepath
        html_get = HTML_web_availibility.split('\\')[:-2]
        # HTML_Core = '\\'.join(html_get) + '\\Core'
        Log = '\\'.join(html_get) + '\\Log'
        # Html = HTML_web_availibility + 'HTML'
        try:
            if not os.path.exists(Log):
                os.makedirs(Log)
            # if not os.path.exists(Html):
            #     os.makedirs(Html)
        except Exception as e:
            print('exception in makedir config file error: ', e)
        return  HTML_web_availibility,select_time_list,feed



def pl_link(url,region):
    print('Scraping url --', url)

    cookie_path = f"\\\\192.168.1.235\\d\\Lazada_Cookie\\Lazada_{region}.txt"

    with open(cookie_path, 'r', encoding='utf8') as f:
        cookie = f.read()
        cookie = cookie.splitlines()
        cookie = random.choice(cookie)

    with open(r'D:\Useragent_list\winndows_UserAgent.txt', 'r', encoding='utf8') as f:
        UserAgent = f.read()
        UserAgent = UserAgent.splitlines()
        useragent = random.choice(UserAgent)

    head = {
        'cookie': cookie,
        'user-agent': useragent,
    }

    #TODO Read Proxy from Google Sheet
    gsheetid = "1m_NqveaeLD3ol_S-5JG2Nc85HxfcxB0cGrEVWmNjbfk"
    sheet_name = "kcp_lazada_PRICESTOCK"
    gsheet_url = "https://docs.google.com/spreadsheets/d/{}/gviz/tq?tqx=out:csv&sheet={}".format(gsheetid, sheet_name)
    df = pd.read_csv(gsheet_url)
    app = []
    for key, value in df.iterrows():
        if 'yes' in value['status']:
            name = value['name']
            app.append(name)
    proxy_name = random.choice(app)

    for key, value in df.iterrows():
        if proxy_name in value['name']:
            proxy = value['proxies']

            if proxy_name == 'unblocker':
                try:
                    print(Fore.WHITE + "==============================unblocker=================================")
                    proxy = proxy.replace('{region}', f'{region}')
                    proxy = json.loads(proxy)
                    main_req = requests.get(url=url, headers=head, proxies=proxy, verify=False)
                    return main_req
                except Exception as e:
                    print(Fore.RED + "-------------Error in Unblocker..........", e)

            elif proxy_name == 'Scraper API':
                try:
                    print(Fore.WHITE + "==============================Scraper=================================")

                    payload = {'api_key': proxy, 'url': url, 'keep_headers': 'true','render':'true'}
                    main_req = requests.get('http://api.scraperapi.com', params=payload, headers=head)
                    return main_req
                except Exception as e:
                    print(Fore.RED + "-------------Error in Scraper..........", e)

            elif proxy_name == 'Crawlera' or proxy_name == 'Crawlera1' or proxy_name == 'Crawlera2' or proxy_name == 'Crawlera3' or proxy_name == 'Crawlera4':
                print(Fore.WHITE + "==============================Crawlera=================================")
                try:
                    CRAWLERA_APIKEY_LIST = [
                        proxy,
                    ]
                    current_proxy = str(random.choice(CRAWLERA_APIKEY_LIST))
                    proxy_host = "proxy.crawlera.com"
                    proxy_port = "8010"
                    proxy_auth = f"{current_proxy}:"
                    crawlera = {
                        "http": "https://{}@{}:{}/".format(proxy_auth, proxy_host, proxy_port),
                        "https": "http://{}@{}:{}/".format(proxy_auth, proxy_host, proxy_port)
                    }
                    head['x-requested-with'] = "XMLHttpRequest"
                    head['X-Crawlera-Cookies'] = "disable"
                    main_req = requests.get(url=url, headers=head, proxies=crawlera, verify=False)
                    return main_req
                except Exception as e:
                    print(Fore.RED + "-------------Error in Crawlera..........", e)

            elif proxy_name == 'instance':
                try:
                    proxyips = [
                        '104.140.183.10:8800',
                        '104.140.183.246:8800',
                        '104.140.215.216:8800',
                        '104.140.183.141:8800',
                        '192.126.161.132:8800',
                        '50.2.15.35:8800',
                        '192.161.162.21:8800',
                        '104.140.183.195:8800',
                        '104.140.73.147:8800',
                        '192.161.162.126:8800',
                        '192.161.162.215:8800',
                        '23.19.97.38:8800',
                        '50.2.25.231:8800',
                        '50.2.15.246:8800',
                        '104.140.215.149:8800',
                        '50.2.25.198:8800',
                        '192.161.162.121:8800',
                        '50.2.25.234:8800',
                        '192.126.161.215:8800',
                        '23.19.97.72:8800',
                        '192.161.162.55:8800',
                        '104.140.183.59:8800',
                        '192.161.162.125:8800',
                        '173.234.232.44:8800',
                        '50.2.15.74:8800',
                        '104.140.183.8:8800',
                        '173.232.7.27:8800',
                        '192.161.162.155:8800',
                        '23.19.97.205:8800',
                        '23.19.97.71:8800',
                        '192.161.162.44:8800',
                        '104.140.183.224:8800',
                        '173.232.7.175:8800',
                        '192.126.161.153:8800',
                        '173.234.232.233:8800',
                        '104.140.183.239:8800',
                        '50.2.25.40:8800',
                        '104.140.183.48:8800',
                        '104.140.215.51:8800',
                        '173.232.7.185:8800',
                        '50.2.15.109:8800',
                        '173.232.7.62:8800',
                        '104.140.183.231:8800',
                        '192.126.161.122:8800',
                        '104.140.215.112:8800',
                        '104.140.73.235:8800',
                        '23.19.97.67:8800',
                        '50.2.25.135:8800',
                        '104.140.73.175:8800',
                        '50.2.25.75:8800',
                        '173.234.232.194:8800',
                        '104.140.73.158:8800',
                        '173.234.232.173:8800',
                        '173.232.7.130:8800',
                        '23.19.97.151:8800',
                        '50.2.15.119:8800',
                        '192.126.161.115:8800',
                        '23.19.97.216:8800',
                        '173.234.232.27:8800',
                        '104.140.215.122:8800',
                        '50.2.15.76:8800',
                        '192.161.162.2:8800',
                        '104.140.73.234:8800',
                        '50.2.25.205:8800',
                        '104.140.215.70:8800',
                        '192.161.162.6:8800',
                        '173.232.7.126:8800',
                        '192.126.161.227:8800',
                        '23.19.97.165:8800',
                        '104.140.73.32:8800',
                        '173.232.7.211:8800',
                        '50.2.15.22:8800',
                        '192.126.161.47:8800',
                        '192.126.161.173:8800',
                        '173.234.232.103:8800',
                        '104.140.73.251:8800',
                        '104.140.215.126:8800',
                        '173.234.232.192:8800',
                        '104.140.215.42:8800',
                        '173.234.232.239:8800',
                        '50.2.25.238:8800',
                        '173.234.232.214:8800',
                        '192.126.161.53:8800',
                        '104.140.73.75:8800',
                        '104.140.215.36:8800',
                        '23.19.97.104:8800',
                        '50.2.15.30:8800',
                        '173.232.7.53:8800',
                        '50.2.25.51:8800',
                        '50.2.25.58:8800',
                        '173.234.232.146:8800',
                        '104.140.215.89:8800',
                        '50.2.15.194:8800',
                        '50.2.15.96:8800',
                        '104.140.73.198:8800',
                        '23.19.97.239:8800',
                        '173.232.7.85:8800',
                        '173.232.7.87:8800',
                        '192.126.161.56:8800',
                        '104.140.73.82:8800'
                    ]

                    proxies = {
                        "http": f"http://{(random.choice(proxyips))}",
                    }
                    main_req = requests.get(url=url, headers=head, proxies=proxies, verify=False)
                    return main_req
                except Exception as e:
                    print(Fore.RED + "-------------Error in Instance..........", e)

            elif proxy_name == 'luminati1' or proxy_name == 'luminati2':
                try:
                    proxy = proxy.replace('{region}', f'{region}')
                    proxy = json.loads(proxy)
                    main_req = requests.get(url=url, headers=head, proxies=proxy, verify=False)
                    return main_req
                except Exception as e:
                    print(Fore.RED + "-------------Error in luminati..........", e)

            elif proxy_name == 'residential':
                try:
                    proxy = json.loads(proxy)
                    main_req = requests.get(url=url, headers=head, proxies=proxy, verify=False)
                    return main_req
                except Exception as e:
                    print(Fore.RED + "-------------Error in luminati..........", e)

            elif proxy_name == 'VPN':
                try:
                    print(Fore.WHITE + "==============================With no proxies=================================")
                    main_req = requests.get(url=url, headers=head)
                    return main_req
                except Exception as e:
                    print(Fore.RED + "-------------Error in Scraper..........", e)

from playwright.sync_api import Playwright, sync_playwright
def upright_main(sku_url,path):
    try:
        sku_code = str(sku_url).split('?')[0].split('/')[-1]
        with sync_playwright() as p:
            browser = p.chromium.launch(channel="msedge", headless=False, slow_mo=50)
            page = browser.new_page()
            page.set_default_timeout(0)

            page.goto(sku_url)
            for i in range(5):  # make the range as long as needed
                page.mouse.wheel(0, 800)
                time.sleep(1)
                i += 1

            response_txt = page.content()

            try:
                if sku_code in response_txt:
                    with open(path, 'w', encoding='utf-8') as f:
                        f.write(page.content())

                if os.path.exists(path):
                    with open(path, 'r',encoding='utf-8' ) as f:
                        page_content = f.read()
            except Exception as e:
                print(e)

            browser.close()

            if sku_code in page_content:
                return True
            else:
                return False

    except Exception as e:
        print("Error in sel fun....-- ",e)